int getchar()
{
return tgt_getchar();
}
